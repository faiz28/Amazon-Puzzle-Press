from django.contrib import admin
from .models import Up_file
# Register your models here.

admin.site.register(Up_file)


